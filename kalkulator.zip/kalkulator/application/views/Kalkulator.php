<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta https-equiv="X-UA-Compatible" content="ie=edge">
	<title>Kalkulator</title>
	</head>
	<body>
		<form action="" method="post">
		<table border="1">
			<tr>
				<td colspan="2" align="center">Form kalkulator</td>
				</tr>
			<tr>
				<td>Angka 1</td>
				<td><input type="text" name="angka1"></td>
				</tr>
			<tr>
				<td>Angka 2</td>
				<td><input type="text" name="angka2"></td>
				</tr>
			<tr>
				<td>Operator</td>
				<td>
					<select name ="operator">
						<option value="*">*</option>
						<option value="/">/</option>
						<option value="+">+</option>
						<option value="-">-</option>
						</select>
					</td>
			</tr>
			<tr>
				<td>
					<input type="submit" name="hitung" value="hitung">
					<button type="reset">reset</button>
				</td>
			</tr>
			<p style="text-align:left"> Armadian Dzaki 2020</p>
			</table>
			</form>
			</body>