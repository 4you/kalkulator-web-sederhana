<div class="Konten">

<!–Map Jalan Romo–>
<iframe src="https://goo.gl/maps/gzCTqT37dQqkVVeK7" width="1000" height="300" frameborder="0″"style="border:0"></iframe>
<hr>

<h1>myhome</h1>
<p>Home Office:<br>
sokowaten tamanan banguntapan,bantul<br>
sokowaten<br>
Phone: 089577245961<br>
Email: <a href="armdndzaki7@gmail.com">contact@armadiandzaki7@gmail.com</a>, armadiandzaki7@gmail.com<br>
</div>