<div class="clearfix"></div>
    <footer>Web Design by Armadian Dzaki - &copy; by Armadian Dzaki </footer>    
</div>
</body>
</html>